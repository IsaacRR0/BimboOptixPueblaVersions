using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

namespace BM_TIA_ROSA_PUEBLA
{
    public static class ObjectTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("BM_TIA_ROSA_PUEBLA");
        public static readonly NodeId screen_horneo = new NodeId(namespaceIndex, new Guid("64f13e86a5ad2e684e3f35286e0bbb35"));
        public static readonly NodeId screen_Inyectoras = new NodeId(namespaceIndex, new Guid("6f602a9c3c427bf7ecd25eace2d98992"));
        public static readonly NodeId MainWindow = new NodeId(namespaceIndex, new Guid("01a7e8933afd7c95fe894b0859308138"));
        public static readonly NodeId screen_Horno = new NodeId(namespaceIndex, new Guid("d77dea90b4844eb34758d28cc1af70dc"));
        public static readonly NodeId screen_Desmoldeador = new NodeId(namespaceIndex, new Guid("40cf35c4438fc0858a023504e77fefbc"));
        public static readonly NodeId screen_Enfriador = new NodeId(namespaceIndex, new Guid("5bf3ccfa67c9236d191caf664bce94f6"));
        public static readonly NodeId screen_GantrydeMoldes = new NodeId(namespaceIndex, new Guid("06accae4ddd0fdf2a01820e12b1f439a"));
        public static readonly NodeId screen_SistemaMOPACTPack = new NodeId(namespaceIndex, new Guid("f8a99b6f85506f27d32234fbaa4a980c"));
        public static readonly NodeId screen_Trenes = new NodeId(namespaceIndex, new Guid("d9d4020d2d909ded581a5150a160ea1f"));
        public static readonly NodeId screen_EmbolsadoVertical = new NodeId(namespaceIndex, new Guid("51893971a2938ecbcc4ccfebe842d792"));
        public static readonly NodeId screen_LineadeDanes = new NodeId(namespaceIndex, new Guid("25ef1109ba0d68d99885bb85e02faa7a"));
        public static readonly NodeId screen_acondicionamientodemasa = new NodeId(namespaceIndex, new Guid("5123b0faab4ce1dc83be7a772d77ae02"));
        public static readonly NodeId screen_empaque = new NodeId(namespaceIndex, new Guid("0bb67c46e3921241bfd6ce2a8da3f4fe"));
        public static readonly NodeId screen_mezcladoras = new NodeId(namespaceIndex, new Guid("e0ef8ab2c881649040d739cbb65e1fbe"));
        public static readonly NodeId screen_trendelaminado = new NodeId(namespaceIndex, new Guid("5746839e17a4a4536725ea870edbd8a9"));
        public static readonly NodeId screen_camaradevapor = new NodeId(namespaceIndex, new Guid("ba6f26588603f570b6bc80f35cbf64a5"));
    }

    public static class VariableTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("BM_TIA_ROSA_PUEBLA");
    }
}
