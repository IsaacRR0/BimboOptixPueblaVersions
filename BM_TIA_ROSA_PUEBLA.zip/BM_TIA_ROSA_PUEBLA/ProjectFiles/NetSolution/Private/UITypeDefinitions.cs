using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "64f13e86a5ad2e684e3f35286e0bbb35")]
public class screen_horneo : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "6f602a9c3c427bf7ecd25eace2d98992")]
public class screen_Inyectoras : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "01a7e8933afd7c95fe894b0859308138")]
public class MainWindow : FTOptix.UI.Window
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "d77dea90b4844eb34758d28cc1af70dc")]
public class screen_Horno : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "40cf35c4438fc0858a023504e77fefbc")]
public class screen_Desmoldeador : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "5bf3ccfa67c9236d191caf664bce94f6")]
public class screen_Enfriador : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "06accae4ddd0fdf2a01820e12b1f439a")]
public class screen_GantrydeMoldes : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "f8a99b6f85506f27d32234fbaa4a980c")]
public class screen_SistemaMOPACTPack : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "d9d4020d2d909ded581a5150a160ea1f")]
public class screen_Trenes : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "51893971a2938ecbcc4ccfebe842d792")]
public class screen_EmbolsadoVertical : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "25ef1109ba0d68d99885bb85e02faa7a")]
public class screen_LineadeDanes : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "5123b0faab4ce1dc83be7a772d77ae02")]
public class screen_acondicionamientodemasa : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "0bb67c46e3921241bfd6ce2a8da3f4fe")]
public class screen_empaque : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "e0ef8ab2c881649040d739cbb65e1fbe")]
public class screen_mezcladoras : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "5746839e17a4a4536725ea870edbd8a9")]
public class screen_trendelaminado : FTOptix.UI.Screen
{
}

[MapType(NamespaceUri = "BM_TIA_ROSA_PUEBLA", Guid = "ba6f26588603f570b6bc80f35cbf64a5")]
public class screen_camaradevapor : FTOptix.UI.Screen
{
}
